/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBQuery {
    Connection con=null;
    Statement st=null;
    ResultSet rs=null;
    
    public int getMaxID() throws ClassNotFoundException, SQLException{
    int i=0;
    String q="select MAX(uid) from userDetails";
    con=DBConnection.getConnection();
    st=con.createStatement();
    rs=st.executeQuery(q);
    if(rs.next())
    {
    
    i=rs.getInt(1);
    }
    return i;
    }
    public int addPerticipate(String fid,String email,String timeslot) throws ClassNotFoundException, SQLException
    {
    int i=0;
    String q="insert into perticipate values('"+fid+"','"+email+"','"+timeslot+"')";
    con=DBConnection.getConnection();
    st=con.createStatement();
    i=st.executeUpdate(q);
    
    return i;
    }
    
    
    public int register(String name,String email,String mob,String city,String pass) throws ClassNotFoundException, SQLException{
    int i=0;
    int id=0;
    id=getMaxID();
    id++;
    String q="insert into userDetails values('"+id+"','"+name+"','"+email+"','"+mob+"','"+city+"','"+pass+"')";
    con=DBConnection.getConnection();
    st=con.createStatement();
    i=st.executeUpdate(q);
    return i;
    }
    
    public int loginCheck(String user,String pass) throws ClassNotFoundException, SQLException{
    int i=0;
    String q="select * from userDetails where email='"+user+"' and password='"+pass+"'";
    con=DBConnection.getConnection();
    st=con.createStatement();
    rs=st.executeQuery(q);
    if(rs.next())
    {
    i=1;
    }
    return i;
    }
      public int getUID(String user) throws ClassNotFoundException, SQLException{
    int i=0;
    String q="select * from userDetails where email='"+user+"' ";
    con=DBConnection.getConnection();
    st=con.createStatement();
    rs=st.executeQuery(q);
    if(rs.next())
    {
    i=rs.getInt("uid");
    }
    return i;
    }
       public int getFID() throws ClassNotFoundException, SQLException{
    int i=0;
    String q="select count(*) from filedetails";
    con=DBConnection.getConnection();
    st=con.createStatement();
    rs=st.executeQuery(q);
    if(rs.next())
    {
    i=rs.getInt(1);
    }
    return i;
    }
      public int addFileDetails(int fid,int uid,String user,String fName,String fPath,String lat,String lon,String comments,String dat) throws ClassNotFoundException, SQLException
      {
      int i=0;
       String q="insert into FileDetails values( '"+fid+"','"+uid+"','"+user+"','"+fName+"','"+fPath+"','"+lat+"','"+lon+"','"+comments+"','"+dat+"') ";
          System.out.println(">>>"+q);
       con=DBConnection.getConnection();
       st=con.createStatement();
       i=st.executeUpdate(q);
      return i;
      }
        public int updateFileDetails(String user,String fname,String lat,String lon,String comments) throws ClassNotFoundException, SQLException
      {
      int i=0;
       String q="update FileDetails set lat='"+lat+"+',lon='"+lon+"' comments='"+comments+"' where email='"+user+"' and fileName='"+fname+"' and lat='a' and lon='a' and comments='a' ";
       con=DBConnection.getConnection();
       st=con.createStatement();
       i=st.executeUpdate(q);
      return i;
      }
        
        
    public String getFileDetails(int count) throws ClassNotFoundException, SQLException{
    int max=0;
    String email="",fileName="",filePath="",lat="",lon="",comments="",dateTime="",res="";
    String q="select MAX(fid) from filedetails";
    con=DBConnection.getConnection();
    st=con.createStatement();
    rs=st.executeQuery(q);
    if(rs.next())
    {
    max=rs.getInt(1);
    }
    
    int temp=max-count;
    String q1="select * from filedetails where fid='"+temp+"'";
    rs=st.executeQuery(q1);
    if(rs.next())
    {
    email=rs.getString("email");
    fileName=rs.getString("fileName");
    filePath=rs.getString("filePath");
    lat=rs.getString("lat");
    lon=rs.getString("lon");
    comments=rs.getString("comments");
    dateTime=rs.getString("dateTime");
    
    }
    
    res=temp+"-"+email+"-"+fileName+"-"+filePath+"-"+lat+"-"+lon+"-"+comments+"-"+dateTime;
    
        System.out.println("***"+res);
    return res;
    }
      public String participantDetails(String fid) throws ClassNotFoundException, SQLException{
    int count1=0,count2=0,count3=0,count4=0;
   
 
    int[] count=new int[4];
    String email="",fileName="",filePath="",lat="",lon="",comments="",dateTime="",res="";
    String q1="select count(*) from perticipate where timeslot='Saturday 6.30 AM'";
    String q2="select count(*) from perticipate where timeslot='Saturday 8.00 AM'";
    String q3="select count(*) from perticipate where timeslot='Sunday 6.30 AM'";
    String q4="select count(*) from perticipate where timeslot='Sunday 8.00 AM'";
    con=DBConnection.getConnection();
    st=con.createStatement();
    rs=st.executeQuery(q1);
    if(rs.next())
    {
    count1=rs.getInt(1);
    count[0]=count1;
    }
    rs=st.executeQuery(q2);
    if(rs.next())
    {
    count2=rs.getInt(1);
    count[1]=count2;
    }
    rs=st.executeQuery(q3);
    if(rs.next())
    {
    count3=rs.getInt(1);
    count[2]=count3;
    }
    rs=st.executeQuery(q4);
    if(rs.next())
    {
    count4=rs.getInt(1);
    count[3]=count4;
    }
    int large=count[0];
    for(int c=0;c<count.length;c++){
    
                        if(count[c] > large){
                                large = count[c];
                        }
    
    }
    String timeslot="";
    if(large==count1){
    timeslot="Saturday 6.30 AM";
    }else if(large==count2){
    timeslot="Saturday 8.00 AM";
    }else if(large==count3){
    timeslot="Sunday 6.30 AM";
    }else if(large==count4){
    timeslot="Sunday 8.00 AM";
    }
         
    
    
    String q5="select * from filedetails where fid='"+fid+"'";
    rs=st.executeQuery(q5);
    if(rs.next())
    {
    
    filePath=rs.getString("filePath");
    lat=rs.getString("lat");
    lon=rs.getString("lon");
    comments=rs.getString("comments");
    dateTime=rs.getString("dateTime");
    
    }
    
    
    
    
   
    
    res=timeslot+"-"+filePath+"-"+lat+"-"+lon+"-"+comments+"-"+dateTime;
    
          System.out.println("******************"+res);
    return res;
    }  
}
