package com.example.pristine;

public interface Global {
	public static final String url ="http://192.168.1.11:8084/Pristine/";
}
