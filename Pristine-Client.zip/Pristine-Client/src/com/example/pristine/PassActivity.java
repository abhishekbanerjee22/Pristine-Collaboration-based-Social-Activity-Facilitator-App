package com.example.pristine;

import java.io.BufferedReader;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import HttpClient.CustomHttpClient;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PassActivity extends Activity {
	public static String name="",email="",mob="",city="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pass);
		final EditText p1=(EditText)findViewById(R.id.APETPass);
		final EditText p2=(EditText)findViewById(R.id.APETCPass);
		Button btn=(Button)findViewById(R.id.ARBtnCRegister);
		
		Button log=(Button)findViewById(R.id.APLogin);
		
		final Intent login=new Intent(this,Login.class);
		
		log.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(login);
			}
		});
		
		btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String pass=p1.getText().toString();
				String cpass=p2.getText().toString();
				
				if(pass.equals(cpass))
				{
					ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
	            	postParameters.add(new BasicNameValuePair("name", name));
	            	postParameters.add(new BasicNameValuePair("email", email));
	            	postParameters.add(new BasicNameValuePair("mob", mob));
	            	postParameters.add(new BasicNameValuePair("city", city));
	            	postParameters.add(new BasicNameValuePair("pass", pass));
					
	            	 String text = "";
			    	BufferedReader reader=null;
					
						
					 
					
						
						 String response = null;
			            	try {
			            		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

			            	   StrictMode.setThreadPolicy(policy); 
			            		
			            	   response = CustomHttpClient.executeHttpPost(Global.url+"registration.jsp", postParameters);
			            	
			            	   String res=response.toString();
			            	 
			            	   res= res.replaceAll("\\s+","");   //removing spaces in between the words    
			            	   
			            	   
			            	   
			            	   if(res.equals("ok"))
			            	   {
			            		  Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_LONG).show(); 
			            		  startActivity(login);
			            		   
			            	   }
			            	   else{
			            		   Toast.makeText(getApplicationContext(), "Registration Not Successful", Toast.LENGTH_LONG).show(); 
				            		  
			            		   
			            	   }
			            	}catch(Exception e)
			            	{
			            		
			            	}
					
					
				}

					
				
				else{
					
					Toast.makeText(getApplicationContext(), "Passwords are not matching!!", Toast.LENGTH_LONG).show();
				}
				
				
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.pass, menu);
		return true;
	}

}
