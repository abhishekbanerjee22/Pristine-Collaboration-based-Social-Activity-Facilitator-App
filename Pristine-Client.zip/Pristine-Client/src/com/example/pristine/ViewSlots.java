package com.example.pristine;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;







import HttpClient.CustomHttpClient;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ViewSlots extends Activity {
	public static String user="",fid="",res="",slot="";
	ImageView img;
	ProgressDialog pDialog;
	Bitmap bitmap;
	String det[];
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_slots);
		
		ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
    	
    	postParameters.add(new BasicNameValuePair("fid", fid+""));
    	
    	  String response = null;
      	try {
      		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

      		StrictMode.setThreadPolicy(policy); 
      		
      	    response = CustomHttpClient.executeHttpPost(Global.url+"perticipateDetails.jsp", postParameters);
      	
      	    res=response.toString();
      	 
      	    res= res.replaceAll("\\s+","");   //removing spaces in between the words    
      	   Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG  ).show();
      	   det=res.split("-");
      	 img = (ImageView)findViewById(R.id.VSImageView);
 	//	final TextView tvUploadBy=(TextView)findViewById(R.id.VSTVUploadedBy);
 	//	final TextView tvFileName=(TextView)findViewById(R.id.VSTVFileName);
 		final TextView tvLat=(TextView)findViewById(R.id.VSTVLat);
 		final TextView tvLon=(TextView)findViewById(R.id.VSTVLon);
 		final TextView tvComments=(TextView)findViewById(R.id.VSTVComments);
 		final TextView tvDate=(TextView)findViewById(R.id.VSTVDate);
 		final TextView tvSlot=(TextView)findViewById(R.id.VSTVSlot);
 	//	final Intent next=new Intent(this,SelectDate.class);
      	   
      	
		
 		det=new String[7];
		det=res.split("-");
		
		
		 new LoadImage().execute(Global.url+det[1]);	
		 
		 //tvUploadBy.setText(det[1]);
		// tvFileName.setText(det[1]);
		 tvLat.setText(det[2]);
		 tvLon.setText(det[3]);
		 tvComments.setText(det[4]);
		 tvDate.setText(det[5]);
		 tvSlot.setText(det[0]);
      	}catch(Exception e)
      	{
      		e.printStackTrace();
      	}
		
		
	}
	private class LoadImage extends AsyncTask<String, String, Bitmap> {
	    @Override
	        protected void onPreExecute() {
	            super.onPreExecute();
	            pDialog = new ProgressDialog(ViewSlots.this);
	            pDialog.setMessage("Loading Image ....");
	            pDialog.show();
	    }
	       protected Bitmap doInBackground(String... args) {
	         try {
	               bitmap = BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());
	        } catch (Exception e) {
	              e.printStackTrace();
	        }
	      return bitmap;
	       }
	       protected void onPostExecute(Bitmap image) {
	         if(image != null){
	           img.setImageBitmap(image);
	           pDialog.dismiss();
	         }else{
	           pDialog.dismiss();
	           Toast.makeText(ViewSlots.this, "Image Does Not exist or Network Error", Toast.LENGTH_SHORT).show();
	         }
	       }
	   }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_slots, menu);
		return true;
	}

}
