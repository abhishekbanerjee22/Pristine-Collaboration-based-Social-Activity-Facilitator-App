 package com.example.pristine;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import HttpClient.CustomHttpClient;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;














import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;





public class UserHome extends Activity {
	    // Activity request codes
		private static final int CAMERA_CAPTURE_IMAGE_REQUEST_CODE = 100;
		String lat="", lon="",addr="";
		 private String imagepath=null;
		public static final int MEDIA_TYPE_IMAGE = 1;
		// directory name to store captured images
		private static final String IMAGE_DIRECTORY_NAME = "Hello Camera";

		private Uri fileUri; // file url to store image
		int serverResponseCode = 0;
		private ImageView imgPreview;
		public static String filePath="",user="";
		private Button btnCapturePicture, btnUpload,btnBrowse;
		String comments="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user_home);
		
		
		final TextView etNext=(TextView)findViewById(R.id.UHTVNext);
		final TextView etLogout=(TextView)findViewById(R.id.UHTVLogout);
		imgPreview = (ImageView) findViewById(R.id.imgPreview);
		
		btnCapturePicture = (Button) findViewById(R.id.UHBtnClick);
		btnBrowse = (Button) findViewById(R.id.UHBtnBrowse);
		btnUpload = (Button) findViewById(R.id.UHBtnUpload);
		final EditText etComments=(EditText)findViewById(R.id.UHETComments);
		final Intent next=new Intent(this,ViewComments.class);
		final Intent prev=new Intent(this,MainActivity.class);
		etLogout.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(prev);
			}
		});
		btnBrowse.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				comments=etComments.getText().toString();
				LocationManager locationManager = (LocationManager) UserHome.this.getSystemService(Context.LOCATION_SERVICE);
				LocationListener locationListener = new LocationListener() {
					public void onLocationChanged(Location location) {
						// Called when a new location is found by the network location provider.
						lat = Double.toString(location.getLatitude());
						lon = Double.toString(location.getLongitude());
						TextView tv = (TextView) findViewById(R.id.AUHTVLoc);
						Toast.makeText(getApplicationContext(), "Your Location is:" + lat + "--" + lon,1).show();
						tv.setText("Your Location is:" + lat + "--" + lon);
					}

					public void onStatusChanged(String provider, int status, Bundle extras) {}
					public void onProviderEnabled(String provider) {}
					public void onProviderDisabled(String provider) {}
				};
				// Register the listener with the Location Manager to receive location updates
				locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
				
				
				    Intent intent = new Intent();
		            intent.setType("image/*");
		            intent.setAction(Intent.ACTION_GET_CONTENT);
		          //  intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
		           // fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE);

		    		//intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
		    		 startActivityForResult(Intent.createChooser(intent, "Complete action using"), 1);
		    		 
				//captureImage();
			}
		});
		
		
		etNext.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ViewComments.user=user;
				startActivity(next);
			}
		});
		btnCapturePicture.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// capture picture
				
				
				LocationManager locationManager = (LocationManager) UserHome.this.getSystemService(Context.LOCATION_SERVICE);
				LocationListener locationListener = new LocationListener() {
					public void onLocationChanged(Location location) {
						// Called when a new location is found by the network location provider.
						lat = Double.toString(location.getLatitude());
						lon = Double.toString(location.getLongitude());
						TextView tv = (TextView) findViewById(R.id.AUHTVLoc);
						Toast.makeText(getApplicationContext(), "Your Location is:" + lat + "--" + lon,1).show();
						tv.setText("Your Location is:" + lat + "--" + lon);
					}

					public void onStatusChanged(String provider, int status, Bundle extras) {}
					public void onProviderEnabled(String provider) {}
					public void onProviderDisabled(String provider) {}
				};
				// Register the listener with the Location Manager to receive location updates
				locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
				captureImage();
			}
		});
		
		/*
		 * Capture image button click event
		 */
		btnUpload.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// upload picture
				//uploadPic();
				comments=etComments.getText().toString();
				uploadFile(filePath);//"/sdcard/aa.jpg");
				
			}
		});
		// Checking camera availability
				if (!isDeviceSupportCamera()) {
					Toast.makeText(getApplicationContext(),
							"Sorry! Your device doesn't support camera",
							Toast.LENGTH_LONG).show();
					// will close the app if the device does't have camera
					finish();
				}
	}
	public String getPath(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
	/*
	 * Here we store the file url as it will be null after returning from camera
	 * app
	 */
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);

		// save file url in bundle as it will be null on scren orientation
		// changes
		outState.putParcelable("file_uri", fileUri);
	}
	
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);

		// get the file url
		fileUri = savedInstanceState.getParcelable("file_uri");
	}
	
	
	
	/**
	 * Receiving activity result method will be called after closing the camera
	 * */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// if the result is capturing Image
		if (requestCode == CAMERA_CAPTURE_IMAGE_REQUEST_CODE) {
			if (resultCode == RESULT_OK) {
				// successfully captured the image
				// display it in image view
				previewCapturedImage();
			} else if (resultCode == RESULT_CANCELED) {
				// user cancelled Image capture
				Toast.makeText(getApplicationContext(),
						"User cancelled image capture", Toast.LENGTH_SHORT)
						.show();
			} else {
				// failed to capture image
				Toast.makeText(getApplicationContext(),
						"Sorry! Failed to capture image", Toast.LENGTH_SHORT)
						.show();
			}
		}
		 if (requestCode == 1 && resultCode == RESULT_OK) {
	            //Bitmap photo = (Bitmap) data.getData().getPath(); 
	          
	            Uri selectedImageUri = data.getData();
	            imagepath = getPath(selectedImageUri);
	            filePath=imagepath;
	            
	        /*    String newPath="";
	            String ig[]=imagepath.split("/");
	            int len=ig.length;
	            String fname=ig[len-1];
	            String fn[]=fname.split(".");
	            fn[0]="IMG_" + user;
	            fname="IMG_" + user + ".jpg";
	            ig[len-1]=fname;
	            for(int i=0;i<len;i++)
	            {
	            	
	            	fname+=ig[i];
	            }
	            filePath=fname;
	            FileInputStream fin;
	            byte b[]=null;
	            try {
	    			fin=new FileInputStream(imagepath);
	    			b=new byte[fin.available()];
	    			fin.read(b);
	    			fin.close();
	    			
	    			
	    			 File f1= new File(filePath);
	 				
	 				
	 				f1.createNewFile();
	 				BufferedWriter writer = new BufferedWriter( new FileWriter(f1));
	 				writer.write(b.toString());
	 				writer.close();
	 	            
	    		} catch (Exception e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	    		}
	            
	            
	           */
	            
	            fileUri=selectedImageUri;
	            Bitmap bitmap=BitmapFactory.decodeFile(imagepath);
	            imgPreview.setImageBitmap(bitmap);
	           
	      
	     }
	}
	
	/**
	 * Checking device has camera hardware or not
	 * */
	private boolean isDeviceSupportCamera() {
		if (getApplicationContext().getPackageManager().hasSystemFeature(
				PackageManager.FEATURE_CAMERA)) {
			// this device has a camera
			return true;
		} else {
			// no camera on this device
			return false;
		}
	}
	/*
	 * Capturing Camera Image will lauch camera app requrest image capture
	 */
	private void captureImage() {
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE);

		intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);

		// start the image capture Intent
		startActivityForResult(intent, CAMERA_CAPTURE_IMAGE_REQUEST_CODE);
	}
	/*
	 * Creating file uri to store image/video
	 */
	public Uri getOutputMediaFileUri(int type) {
		return Uri.fromFile(getOutputMediaFile(type));
	}

	/*
	 * returning image / video
	 */
	private static File getOutputMediaFile(int type) {

		// External sdcard location
		File mediaStorageDir = new File(
				Environment
						.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
				IMAGE_DIRECTORY_NAME);

		// Create the storage directory if it does not exist
		if (!mediaStorageDir.exists()) {
			if (!mediaStorageDir.mkdirs()) {
				Log.d(IMAGE_DIRECTORY_NAME, "Oops! Failed create "
						+ IMAGE_DIRECTORY_NAME + " directory");
				return null;
			}
		}

		// Create a media file name
		//String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
				//Locale.getDefault()).format(new Date());
		File mediaFile;
		if (type == MEDIA_TYPE_IMAGE) {
			filePath=mediaStorageDir.getPath() + File.separator+ "IMG_" + user + ".jpg";
			mediaFile = new File(mediaStorageDir.getPath() + File.separator+ "IMG_" + user + ".jpg");
			
		}  else {
			return null;
		}

		return mediaFile;
	}
	
	/*
	 * Display image from a path to ImageView
	 */
	private void previewCapturedImage() {
		try {
			

			imgPreview.setVisibility(View.VISIBLE);

			// bimatp factory
			BitmapFactory.Options options = new BitmapFactory.Options();

			// downsizing image as it throws OutOfMemory Exception for larger
			// images
			options.inSampleSize = 8;

			final Bitmap bitmap = BitmapFactory.decodeFile(fileUri.getPath(),
					options);

			imgPreview.setImageBitmap(bitmap);
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user_home, menu);
		return true;
	}
	
	
	
	public int uploadFile(String sourceFileUri) {
        String upLoadServerUri = Global.url+"imageReceiveFromAndroid.jsp";
        String fileName = sourceFileUri;

        HttpURLConnection conn = null;
        DataOutputStream dos = null; 
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        int bytesRead, bytesAvailable, bufferSize;
        byte[] buffer;
        int maxBufferSize = 1 * 1024 * 1024;
        File sourceFile = new File(sourceFileUri);
        if (!sourceFile.isFile()) {
         Log.e("uploadFile", "Source File Does not exist");
         return 0;
        }
            try { 
             FileInputStream fileInputStream = new FileInputStream(sourceFile);
             URL url = new URL(upLoadServerUri);
             conn = (HttpURLConnection) url.openConnection(); // Open a HTTP  connection to  the URL
             conn.setDoInput(true); // Allow Inputs
             conn.setDoOutput(true); // Allow Outputs
             conn.setUseCaches(false); // Don't use a Cached Copy
             conn.setRequestMethod("POST");
             conn.setRequestProperty("Connection", "Keep-Alive");
             conn.setRequestProperty("ENCTYPE", "multipart/form-data");
             conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
             conn.setRequestProperty("uploaded_file", fileName);
             conn.setRequestProperty("user", "aa");
             dos = new DataOutputStream(conn.getOutputStream());
   
             dos.writeBytes(twoHyphens + boundary + lineEnd);
             //dos.writeUTF("Content-Disposition: form-data; name=\"lat\";lat=\""+ lat + "\"" + lineEnd);
           //  dos.writeUTF(lon);
             dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\""+ fileName + "\"" + lineEnd);
             
             dos.writeBytes(lineEnd);
   
             bytesAvailable = fileInputStream.available(); // create a buffer of  maximum size
   
             bufferSize = Math.min(bytesAvailable, maxBufferSize);
             buffer = new byte[bufferSize];
   
             // read file and write it into form...
             bytesRead = fileInputStream.read(buffer, 0, bufferSize); 
               
             while (bytesRead > 0) {
               dos.write(buffer, 0, bufferSize);
               bytesAvailable = fileInputStream.available();
               bufferSize = Math.min(bytesAvailable, maxBufferSize);
               bytesRead = fileInputStream.read(buffer, 0, bufferSize);              
              }
   
             // send multipart form data necesssary after file data...
             dos.writeBytes(lineEnd);
             dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
   
             // Responses from the server (code and message)
             serverResponseCode = conn.getResponseCode();
             String serverResponseMessage = conn.getResponseMessage();
              
             Log.i("uploadFile", "HTTP Response is : " + serverResponseMessage + ": " + serverResponseCode);
             if(serverResponseCode == 200){
                 runOnUiThread(new Runnable() {
                      public void run() {
                         
                          Toast.makeText(getApplicationContext(), "File Upload Complete.", Toast.LENGTH_SHORT).show();
                      }
                  });               
             }   
             
             //close the streams //
             fileInputStream.close();
             dos.flush();
             dos.close();
              
        } catch (MalformedURLException ex) { 
            
            ex.printStackTrace();
            Toast.makeText(getApplicationContext(), "MalformedURLException", Toast.LENGTH_SHORT).show();
            Log.e("Upload file to server", "error: " + ex.getMessage(), ex); 
        } catch (Exception e) {
            
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Exception : " + e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.e("Upload file to server Exception", "Exception : " + e.getMessage(), e); 
        }
          
            try {
				Thread.sleep(3000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            
            ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
        	postParameters.add(new BasicNameValuePair("user", user));
        	postParameters.add(new BasicNameValuePair("lat", lat));
        	postParameters.add(new BasicNameValuePair("lon", lon));
        	postParameters.add(new BasicNameValuePair("fileName", fileName)); 
        	postParameters.add(new BasicNameValuePair("comments", comments)); 
	    	  String response = null;
          	try {
          		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

          		StrictMode.setThreadPolicy(policy); 
          		
          	   response = CustomHttpClient.executeHttpPost(Global.url+"sendValues.jsp", postParameters);
          	
          	   String res=response.toString();
          	 
          	   res= res.replaceAll("\\s+","");   //removing spaces in between the words    
          	   Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG  ).show();
          	   if(res.equals("ok"))
          	   {
          		   
          		 Toast.makeText(getApplicationContext(), "File Upload", Toast.LENGTH_SHORT).show();
                 
          	   }
          	}catch(Exception e)
          	{
          		e.printStackTrace();
          	}
            
            
            
            
            
        return serverResponseCode; 
        
        
        
        
        
       }


}
