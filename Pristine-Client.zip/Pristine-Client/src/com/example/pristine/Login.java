package com.example.pristine;

import java.io.BufferedReader;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;



import HttpClient.CustomHttpClient;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class Login extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		
		final EditText u=(EditText)findViewById(R.id.LAETUser);
		final EditText p=(EditText)findViewById(R.id.LAETPass);
		final Intent next=new Intent(this,UserHome.class);
				
		final Button ibLogin=(Button)findViewById(R.id.LABtnLogin);
		ibLogin.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String user=u.getText().toString();
				String pass=p.getText().toString();
				
				ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
            	postParameters.add(new BasicNameValuePair("user", user));
            	postParameters.add(new BasicNameValuePair("pass", pass));
				
            	 String text = "";
		    	  BufferedReader reader=null;
				
				if("".equals(user) && "".equals(pass))
				{
					Toast.makeText(getApplicationContext(), "Please,Enter the Username and Password.", Toast.LENGTH_LONG).show();
				}
				
				else if("".equals(user))
				{
					Toast.makeText(getApplicationContext(), "Please,Enter the Username.", Toast.LENGTH_LONG).show();
				}
				
				else if("".equals(pass))
				{
					Toast.makeText(getApplicationContext(), "Please,Enter the Password.", Toast.LENGTH_LONG).show();
				}
				
				 // Our Main Business Starts Here
				else
				{
					
					 String response = null;
		            	try {
		            		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

		            		StrictMode.setThreadPolicy(policy); 
		            		
		            	   response = CustomHttpClient.executeHttpPost(Global.url+"logincheck.jsp", postParameters);
		            	
		            	   String res=response.toString();
		            	 
		            	   res= res.replaceAll("\\s+","");   //removing spaces in between the words    
		            	 //  Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG  ).show();
		            	   
		            	   if(res.equals("ok"))
		            	   {Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_LONG  ).show();
		            	   UserHome.user=user;
		            	   startActivity(next);
		            	   }
		            	  
		            	   else{
		            		   Toast.makeText(getApplicationContext(), "Username and password are not matching", Toast.LENGTH_LONG).show();   
		            		   
		            	   }
		            	}catch(Exception e){e.printStackTrace();}
		       }
			
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

}
