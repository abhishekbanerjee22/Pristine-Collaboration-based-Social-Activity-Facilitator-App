package com.example.pristine;

import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;





import HttpClient.CustomHttpClient;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ViewComments extends Activity {
	public static String user="";
	String res="";
	public static int count=0;
	ImageView img;
	ProgressDialog pDialog;
	Bitmap bitmap;
	String det[];
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_comments);
		final Button btn=(Button)findViewById(R.id.VCBtnLoad);
		final Button btnVM=(Button)findViewById(R.id.VCBtnViewOnMap);
		final Button btnP=(Button)findViewById(R.id.VCBtnPerticipate);
		img = (ImageView)findViewById(R.id.VCImageView);
		final TextView tvUploadBy=(TextView)findViewById(R.id.VCTVUploadedBy);
		final TextView tvFileName=(TextView)findViewById(R.id.VCTVUploadedBy);
		final TextView tvLat=(TextView)findViewById(R.id.VCTVLat);
		final TextView tvLon=(TextView)findViewById(R.id.VCTVLon);
		final TextView tvComments=(TextView)findViewById(R.id.VCTVComments);
		final TextView tvDate=(TextView)findViewById(R.id.VCTVDate);
		final Intent next=new Intent(this,SelectDate.class);
		final Intent next1=new Intent(this,myMap.class);
		
		btnVM.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "Lat:"+det[4], 1).show();
				Toast.makeText(getApplicationContext(), "Lat:"+det[5], 1).show();
				myMap.latitude1=Double.parseDouble(det[4]);
				myMap.longitude1=Double.parseDouble(det[5]);
				myMap.det=res;
				startActivity(next1);
			}
		});
		
		
		btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 
				
				ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
	        	postParameters.add(new BasicNameValuePair("user", user));
	        	postParameters.add(new BasicNameValuePair("count", count+""));
	        	count++;
		    	  String response = null;
	          	try {
	          		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

	          		StrictMode.setThreadPolicy(policy); 
	          		
	          	   response = CustomHttpClient.executeHttpPost(Global.url+"getFileDetails.jsp", postParameters);
	          	
	          	    res=response.toString();
	          	 
	          	   res= res.replaceAll("\\s+","");   //removing spaces in between the words    
	          	   Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG  ).show();
	          	}catch(Exception e)
	          	{
	          		e.printStackTrace();
	          	}
				
				
				
				det=new String[8];
				det=res.split("-");
				
				
				Toast.makeText(getApplicationContext(), "File Path->"+Global.url+det[3], Toast.LENGTH_LONG  ).show();
				
				 new LoadImage().execute(Global.url+det[3]);	
				 
				 tvUploadBy.setText(det[1]);
				 tvFileName.setText(det[2]);
				 tvLat.setText(det[4]);
				 tvLon.setText(det[5]);
				 tvComments.setText(det[6]);
				 tvDate.setText(det[7]);
				
			}
		});
		
		btnP.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				SelectDate.user=user;
				SelectDate.fid=det[0];
				startActivity(next);
			}
		});
		
	}
	private class LoadImage extends AsyncTask<String, String, Bitmap> {
	    @Override
	        protected void onPreExecute() {
	            super.onPreExecute();
	            pDialog = new ProgressDialog(ViewComments.this);
	            pDialog.setMessage("Loading Image ....");
	            pDialog.show();
	    }
	       protected Bitmap doInBackground(String... args) {
	         try {
	               bitmap = BitmapFactory.decodeStream((InputStream)new URL(args[0]).getContent());
	        } catch (Exception e) {
	              e.printStackTrace();
	        }
	      return bitmap;
	       }
	       protected void onPostExecute(Bitmap image) {
	         if(image != null){
	           img.setImageBitmap(image);
	           pDialog.dismiss();
	         }else{
	           pDialog.dismiss();
	           Toast.makeText(ViewComments.this, "Image Does Not exist or Network Error", Toast.LENGTH_SHORT).show();
	         }
	       }
	   }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

}
