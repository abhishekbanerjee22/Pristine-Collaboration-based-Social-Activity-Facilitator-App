package com.example.pristine;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class myMap extends Activity {
	public static double latitude1,longitude1;
	public static String user="",det="";
	private WebView position;
	private TextView textInfo;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map);

		position = (WebView) findViewById(R.id.webView);
		position.getSettings().setJavaScriptEnabled(true);
        final Button back=(Button)findViewById(R.id.MapBack);
        final Intent i=new Intent(this,ViewComments.class);
		textInfo = (TextView) findViewById(R.id.MaptextInfo);
		textInfo.setText("Location : \nLat:"+latitude1+"\nLon:"+longitude1);

		
		String url=Global.url+"showingPixelCoordinates.jsp?det="+det;
		position.loadUrl(url);
		
		
		back.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ViewComments.user=user;
				startActivity(i);
			}
		});
		
		
		
	/*	LocationManager locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		//For Retrieving new Location
		LocationListener locListener = new MyLocationListener();

		locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,
				locListener);*/
	}

	
}
