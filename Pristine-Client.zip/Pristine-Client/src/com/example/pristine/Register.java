package com.example.pristine;



import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Register extends Activity {
	private Pattern pattern,pattern1;
	private Matcher matcher,matcher1;
	Spinner spCity;
	String city=""; 
	ArrayAdapter<String> adapterSPCity;
	String cities[] = { "Select", "Bangalore", "Chennai", "Delhi","Mumbai", "Kolkata" };
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		
		spCity = (Spinner)findViewById(R.id.spCity);
		  // Initialize and set Adapter
		adapterSPCity = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, cities);
		spCity.setAdapter(adapterSPCity);
		
		final EditText etName=(EditText)findViewById(R.id.ARETName);
		final EditText etEmail=(EditText)findViewById(R.id.ARETEmail);
		final EditText etMob=(EditText)findViewById(R.id.ARETMobile);
		Button bR=(Button)findViewById(R.id.ARBtnRegister);
		final Intent iPass=new Intent(this,PassActivity.class);
		
		
		spCity.setOnItemSelectedListener(new OnItemSelectedListener() {
			 
	            @Override
	            public void onItemSelected(AdapterView<?> adapter, View v,
	                    int position, long id) {
	                // On selecting a spinner item
	            	city = adapter.getItemAtPosition(position).toString();
	 
	              
	                
	            } 
	            
	            
	            
	            @Override
	            public void onNothingSelected(AdapterView<?> arg0) {
	                // TODO Auto-generated method stub
	 
	            }
	        });
		
		bR.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				String name=etName.getText().toString();
				String email=etEmail.getText().toString();
				String mob=etMob.getText().toString();
				
				String em=email;
				String p="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[c,e,n][o,d,e][m,t,u])$";
				pattern = Pattern.compile(p);
				matcher = pattern.matcher(em);
				
				String p1="^[7-9][0-9]{9}$";
				pattern1 = Pattern.compile(p1);
				matcher1 = pattern1.matcher(mob);
				 if("".equals(name))
					{
						Toast.makeText(getApplicationContext(), " Enter the Name.", Toast.LENGTH_LONG).show();
					}
					
					else if("".equals(email))
					{
						Toast.makeText(getApplicationContext(), " Enter the Email.", Toast.LENGTH_LONG).show();
					}
					else if("".equals(mob))
						{
							Toast.makeText(getApplicationContext(), " Enter the Mobile.", Toast.LENGTH_LONG).show();
						}
						
						else if("".equals(city))
						{
							Toast.makeText(getApplicationContext(), " Select City.", Toast.LENGTH_LONG).show();
						}
						
				
				 else if(matcher.matches()==false)
					{
						Toast.makeText(getApplicationContext(), " Enter Correct Email.", Toast.LENGTH_LONG).show();
					}
					else if(matcher1.matches()==false)
					{
						Toast.makeText(getApplicationContext(), " Enter Correct Mobile Number.", Toast.LENGTH_LONG).show();
					}
					else{
						PassActivity.name=name;
						PassActivity.email=email;
						PassActivity.mob=mob;
						PassActivity.city=city;
						startActivity(iPass);
						
					}
				
				
			
				
			}
		});
		
	
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.register, menu);
		return true;
	}

}
