package com.example.pristine;

import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import HttpClient.CustomHttpClient;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SelectDate extends Activity {
public static String user="",fid="",res="",slot="";
Intent next=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_select_date);
		final Button btn1=(Button)findViewById(R.id.SDBtnSlot1);
		final Button btn2=(Button)findViewById(R.id.SDBtnSlot2);
		final Button btn3=(Button)findViewById(R.id.SDBtnSlot3);
		final Button btn4=(Button)findViewById(R.id.SDBtnSlot4);
		final Button btn5=(Button)findViewById(R.id.SDBtnView);
		next=new Intent(this,ViewSlots.class);
		
		
		
		btn1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
				
			slot="Saturday 6.30 AM";	
			send(slot);	
					
			}
		});
btn2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
				
			slot="Saturday 8.00 AM";	
			send(slot);	
					
			}
		});
		
btn3.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
	
		
	slot="Sunday 6.30 AM";	
	send(slot);	
			
	}
});

btn4.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
	
		
	slot="Sunday 8.00 AM";	
	send(slot);	
			
	}
});

btn5.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		ViewSlots.user=user;
		   ViewSlots.fid=fid;
		   
		   startActivity(next);
	}
});	
		
	}
	public void send(String slot){
		
		ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
    	postParameters.add(new BasicNameValuePair("user", user));
    	postParameters.add(new BasicNameValuePair("fid", fid+""));
    	postParameters.add(new BasicNameValuePair("timeSlot", slot));
    	  String response = null;
      	try {
      		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

      		StrictMode.setThreadPolicy(policy); 
      		
      	   response = CustomHttpClient.executeHttpPost(Global.url+"perticipate.jsp", postParameters);
      	
      	    res=response.toString();
      	 
      	   res= res.replaceAll("\\s+","");   //removing spaces in between the words    
      	   Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG  ).show();
      	   if(res.equals("ok"))
      	   {
      		   
      		 Toast.makeText(getApplicationContext(), "Perticipation Successful", Toast.LENGTH_LONG  ).show();
      	   }
      	 if(res.equals("notok"))
    	   {
    		   
    		 Toast.makeText(getApplicationContext(), "Perticipation Not Successful", Toast.LENGTH_LONG  ).show();
    	   }
      	}catch(Exception e)
      	{
      		e.printStackTrace();
      	}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.select_date, menu);
		return true;
	}

}
